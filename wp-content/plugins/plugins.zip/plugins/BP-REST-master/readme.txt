=== BP-REST ===
Contributors:      BuddyPress
Donate link:       https://buddypress.org
Requires at least: 4.5
Tested up to:      4.5
Stable tag:        0.1.0
License:           GPLv2 or later
License URI:       http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

Access your BuddyPress site's data through an easy-to-use HTTP REST API.

== Installation ==

= Manual Installation =

1. Upload the entire `/bp-rest` directory to the `/wp-content/plugins/` directory.
2. Activate BP-REST through the 'Plugins' menu in WordPress.

== Changelog ==

= 0.1.0 =
* First release

== Upgrade Notice ==

= 0.1.0 =
First Release
